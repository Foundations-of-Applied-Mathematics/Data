import subprocess

subprocess.call("find .. -type f | wc -l", shell=True)
